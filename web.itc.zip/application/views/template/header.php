<?php

?>
<title>Sistem Template CodeIgniter Template</title>
  		
		<script type="text/javascript" src="<?php echo base_url('asset/bootstrap/js/jquery-1.10.2.min.js');?>"></script>
        <script type="text/javascript" src="<?php echo base_url('asset/bootstrap/js/bootstrap.min.js');?>"></script>
       
        <link href="<?php echo base_url('asset/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/bootstrap/css/bootstrap-theme.min.css');?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/custom.css');?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/bootstrap/css/normalize.css');?>" rel="stylesheet">
        
    <!--    
         <script type="text/javascript" src="<?php echo base_url('-asset/validator/js/bootstrapValidator.min.js');?>"></script>
        <script type="text/javascript" src="<?php echo base_url('-asset/valid.js');?>"></script>
        <link href="<?php echo base_url('-asset/validator/css/bootstrapValidator.min.css');?>" rel="stylesheet">