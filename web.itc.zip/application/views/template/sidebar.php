<?php

?>
<h3>Main Content</h3> 
  <ul> 
  <li><a href="#">Conflantur</a></li> 
 
 
  <li><a href="#">Externarum vi</a></li> 
  <li><a href="#">Essem paulo</a></li> 
  <li><a href="#">Aeque fecto ii</a></li> 
  <li><a href="#">Quo locis utens</a></li> 
  </ul> 
 
 <h3>Related Web Sites</h3> 
 <ul> 
 <li><a href="#">Plus vi</a></li> 
 <li><a href="#">Agi praecise</a></li> 
 <li><a href="#">Infinitum veritates</a></li> 
 <li><a href="#">Corporea ac perpauca</a></li> 
 <li><a href="#">Aeque fecto</a></li> 
 </ul>
Setelah memiliki view ketiga ar