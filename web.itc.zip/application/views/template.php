<html> 
	<head> 
 		 <div id="header"> 
	  		<!--Area Header--> 
			<?php echo $_header;?> 
		</div>	
 	</head>
   
  <body> 
	  	<div id="wrap"> 
	  		<div id="nav"> 
		  		<!--Area Header--> 
				<?php echo $_nav;?>
				<?php echo $_reg;?> 
			</div> 
			<div id="menu"> 
			  	<!--Area Top Menu --> 
			  	<?php echo $_top_menu;?> 
		  	</div> 
	  	<div id="contentwrap"> 
		  	<div id="content"> 
		  		<!--Area content --> 
		  		<?php echo $_content;?> 
		 	</div> 
	 
		  	<div id="sidebar"> 
		  	<!--Area Right Menu--> 
		  	<?php echo $_right_menu;?> 
		  	</div> 
	  		<div style="clear: both;"></div> 
	  	</div> 
	 
	  	<div id="footer"> 
	  		<p>Copyright </p> 
	  	</div> 
  	</div> 
  </body> 
</html>