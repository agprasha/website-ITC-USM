<?php
class Member extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->model('itc_m');
        $this->load->library(array('template','session'));
    }
    
     function register()
    {
        $form_data = $this->input->post('data');
        if (!empty($form_data))
        {
            $form_data['password'] = md5($form_data['password']);
            $this->itc_m->register($form_data);
            $this->session->set_flashdata('berhasil', 'Pendaftaran berhasil, Anda dapat masuk ke dalam sistem');
            redirect('member/login');
        }
        $this->load->view('register');
    }
    
    function login()
    {
        $form_data = $this->input->post('data');
        if (!empty($form_data))
        {
            if ($this->itc_m->login($form_data['username'], $form_data['password'], 1))
            {
                redirect('member/index');
            }
            else
            {
                //redirect('member/login');
                $this->template->display('index');
                echo 
                " <script>
		            alert('Cek Usename dan Password / Belum Di Konfirmasi Oleh ADMIN!');
		            history.go(-1);
		          </script>";
            }
        }
        $this->load->view('member');
        //$this->template->display('index');
        
    }
    
     function index()
    {
        if ($this->session->userdata('logged_in'))
        	
        {
            //Setelah Login... Dashboard
            redirect('member/cek_level');
            //$this->load->view('member');
            //$this->template->display('test');
        }
        else
        {
            //Home... / Login dan Register
            //redirect('member/login');
            $this->template->display('index');
            //redirect('cek_level');
        }
    }
    
    function cek_level(){
    	if ($this->session->userdata('level')== 'Admin')
    	{
			$this->load->view('member');
		}
		elseif ($this->session->userdata('level')== 'Tutor')
		{
			$this->load->view('tutor');
		}
		else
		{
			$this->load->view('user');
		}
	}
    
     function logout()
    {
        $this->itc_m->logout();
        redirect('member');
    }
    
    
}
?>